import pygame
import time
import easygui
import random

ij=	easygui.indexbox(msg='请选择模式', title='井字棋', choices=('人机模式', '人人模式'), image=None)

heiwin = False
baiwin = False
ping = False
answer=2
pygame.init()

screen = pygame.display.set_mode([288, 512])
background = pygame.image.load("all/background.jpg")
going=True
pygame.display.set_caption("井字棋")
x=0
y=0
weizhi={1:(52,139),2:(125,139),3:(204,139),4:(52,233),5:(125,233),6:(204,233),7:(52,337),8:(125,337),9:(204,337)}
nowinner=True

iii=True

blithei=[]
blitbai=[]
buzhouhei={}
buzhoubai={}
kong=[1,2,3,4,5,6,7,8,9]
turn=[1,2,3,4,5,6,7,8,9]
def fangyihei():

    global answer
    al=range(1,10)
    ra=random.choice(al)
    o=open("all/防疫%i.txt"%ra)
    thing=o.read()
    easygui.msgbox(msg='黑色胜利了', title='井字棋', image=None)
    answer = easygui.indexbox(msg=thing, title='井字棋', choices=('知道了','重新开始'), image=None)
def fangyibai():
    al = range(1, 10)
    ra = random.choice(al)
    o = open("all/防疫%i.txt" % ra)
    global answer
    o = open("all/防疫1.txt")
    thing = o.read()
    easygui.msgbox(msg='白色胜利了', title='井字棋', image=None)
    answer = easygui.indexbox(msg=thing, title='井字棋', choices=('知道了', '重新开始'), image=None)

def fangyiping():
    al = range(1, 10)
    ra = random.choice(al)
    o = open("all/防疫%i.txt" % ra)
    global answer
    o = open("all/防疫1.txt")
    thing = o.read()
    easygui.msgbox(msg='平局了', title='井字棋', image=None)
    answer = easygui.indexbox(msg=thing, title='井字棋', choices=('知道了', '重新开始'), image=None)

def playagain():
    global x
    global y
    if 182>x>70 and 109>y>70:
        return True
def easycomputer():

    return random.choice(kong)

def blii():
    for ks in blithei:
        b=ks-1
        heihei=pygame.image.load("all/hei%i.png"%b)
        screen.blit(heihei, weizhi[ks])

    for ws in blitbai:
        b=ws-1
        baibai=pygame.image.load("all/bai%i.png"%b)
        screen.blit(baibai, weizhi[ws])

def win():
    global heiwin
    global nowinner
    global baiwin
    global ping
    if 1 in blithei and 2 in blithei and 3 in blithei:
        heisheng=pygame.image.load("all/黑胜.png")
        screen.blit(heisheng, (28,392))
        nowinner=False
        heiwin=True
        fangyihei()

    elif 4 in blithei and 5 in blithei and 6 in blithei:
        heisheng = pygame.image.load("all/黑胜.png")
        screen.blit(heisheng, (28, 392))
        nowinner = False
        heiwin=True
        fangyihei()
    elif 7 in blithei and 8 in blithei and 9 in blithei:
        heisheng = pygame.image.load("all/黑胜.png")
        screen.blit(heisheng, (28, 392))
        nowinner = False
        heiwin=True
        fangyihei()
    elif 1 in blithei and 4 in blithei and 7 in blithei:
        heisheng = pygame.image.load("all/黑胜.png")
        screen.blit(heisheng, (28, 392))
        nowinner = False
        heiwin=True
        fangyihei()
    elif 2 in blithei and 5 in blithei and 8 in blithei:
        heisheng = pygame.image.load("all/黑胜.png")
        screen.blit(heisheng, (28, 392))
        nowinner = False
        heiwin=True
        fangyihei()
    elif 3 in blithei and 6 in blithei and 9 in blithei:
        heisheng = pygame.image.load("all/黑胜.png")
        screen.blit(heisheng, (28, 392))
        nowinner = False
        heiwin=True
        fangyihei()
    elif 1 in blithei and 5 in blithei and 9 in blithei:
        heisheng = pygame.image.load("all/黑胜.png")
        screen.blit(heisheng, (28, 392))
        nowinner = False
        heiwin=True
        fangyihei()
    elif 3 in blithei and 5 in blithei and 7 in blithei:
        heisheng = pygame.image.load("all/黑胜.png")
        screen.blit(heisheng, (28, 392))
        nowinner = False
        heiwin=True
        fangyihei()
    elif 1 in blitbai and 2 in blitbai and 3 in blitbai:
        baisheng = pygame.image.load("all/白胜.png")
        screen.blit(baisheng, (28, 392))
        nowinner = False
        baiwin=True
        fangyibai()
    elif 4 in blitbai and 5 in blitbai and 6 in blitbai:
        baisheng = pygame.image.load("all/白胜.png")
        screen.blit(baisheng, (28, 392))
        nowinner = False
        baiwin=True
        fangyibai()
    elif 7 in blitbai and 8 in blitbai and 9 in blitbai:
        baisheng = pygame.image.load("all/白胜.png")
        screen.blit(baisheng, (28, 392))
        nowinner = False
        baiwin=True
        fangyibai()
    elif 1 in blitbai and 4 in blitbai and 7 in blitbai:
        baisheng = pygame.image.load("all/白胜.png")
        screen.blit(baisheng, (28, 392))
        nowinner = False
        baiwin=True
        fangyibai()
    elif 2 in blitbai and 5 in blitbai and 8 in blitbai:
        baisheng = pygame.image.load("all/白胜.png")
        screen.blit(baisheng, (28, 392))
        nowinner = False
        baiwin=True
        fangyibai()
    elif 3 in blitbai and 6 in blitbai and 9 in blitbai:
        baisheng = pygame.image.load("all/白胜.png")
        screen.blit(baisheng, (28, 392))
        nowinner = False
        baiwin=True
        fangyibai()
    elif 1 in blitbai and 5 in blitbai and 9 in blitbai:
        baisheng = pygame.image.load("all/白胜.png")
        screen.blit(baisheng, (28, 392))
        nowinner = False
        baiwin=True
        fangyibai()
    elif 3 in blitbai and 5 in blitbai and 7 in blitbai:
        baisheng = pygame.image.load("all/白胜.png")
        screen.blit(baisheng, (28, 392))
        nowinner = False
        baiwin=True
        fangyibai()
    elif len(kong)==0:
        ping=pygame.image.load("all/平.png")
        screen.blit(ping, (28, 340))
        nowinner = False
        baiwin=True
        ping = True
        fangyiping()
    else:
        pass

def getstep():
    if (67 > x > 30) and (156 > y > 104):
        step = 1

    elif (144 > x > 109) and (159 > y > 114):
        step = 2

    elif (229 > x > 189) and (149 > y > 111):
        step = 3

    elif (66 > x > 19) and (257 > y > 209):
        step = 4

    elif (143 > x > 107) and (262 > y > 202):
        step = 5

    elif (223 > x > 180) and (253 > y > 197):
        step = 6

    elif (62 > x > 20) and (366 > y > 305):
        step = 7

    elif (141 > x > 103) and (371 > y > 302):
        step = 8

    elif (214 > x > 184) and (364 > y > 306):
        step = 9

    else:
        step=0
    return step


keep_going = True
clock = pygame.time.Clock()
if ij==1:
    while True:
        ko=True
        going=True
        iii = True
        if iii == True:
            for t in range(len(turn)):
                if ko==True:
                    keep_going = True

                while keep_going:

                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:

                            exit()

                    if going:
                        screen.blit(background, (0, 0))
                        hei = pygame.image.load("all/hei.png")
                        bai = pygame.image.load("all/bai.png")
                        again=pygame.image.load("all/重新开始.png")
                        mouse = pygame.mouse.get_pos()
                        x, y = mouse
                        if nowinner==True:
                            if turn[t]%2==1:
                                s=screen.blit(hei,mouse )
                                if event.type==pygame.MOUSEBUTTONDOWN:
                                    step=getstep()
                                    if step in kong :
                                        a = kong.index(step)
                                        del kong[kong.index(step)]
                                        keep_going=False

                                        blithei.append(step)
                                        buzhouhei[step] = weizhi[step]
                                        screen.blit(hei, weizhi[step])

                                    else:
                                        pass
                            if turn[t]%2==0:
                                screen.blit(bai, mouse)

                                if event.type == pygame.MOUSEBUTTONDOWN:
                                    step = getstep()
                                    if step in kong :
                                        del kong[kong.index(step)]
                                        keep_going=False
                                        blitbai.append(step)
                                        buzhoubai[step]=weizhi[step]
                                        screen.blit(bai, weizhi[step])
                                        
                                    else:
                                        pass

                    if event.type == pygame.MOUSEBUTTONDOWN or answer==0 or answer==1:

                        if playagain()==True or answer==0 or answer==1:
                            keep_going = False
                            blithei = []
                            answer=2
                            iii = False
                            blitbai = []
                            buzhouhei = {}
                            buzhoubai = {}
                            nowinner = True
                            going = False
                            ko=False
                            kong = [1, 2, 3, 4, 5, 6, 7, 8, 9]

                    blii()
                    win()
                    screen.blit(again,(100,70))
                    pygame.display.update()
                    clock.tick(100)


if ij==0:
    easy=ij
    if easy==0:

        while True:
            ko = True
            going = True
            iii = True
            if iii == True:
                ti = random.randint(0, 1)

                for t in range(len(turn)):

                    if ko == True:
                        keep_going = True

                    while keep_going:

                        for event in pygame.event.get():
                            if event.type == pygame.QUIT:
                                exit()

                        if going:
                            screen.blit(background, (0, 0))
                            hei = pygame.image.load("all/hei.png")
                            bai = pygame.image.load("all/bai.png")
                            again = pygame.image.load("all/重新开始.png")

                            mouse = pygame.mouse.get_pos()
                            x, y = mouse
                            if nowinner == True:
                                if ti==0:

                                    if turn[t] % 2 == 1:

                                        step = easycomputer()
                                        if step in kong:
                                            a = kong.index(step)
                                            del kong[kong.index(step)]
                                            keep_going = False

                                            blithei.append(step)
                                            buzhouhei[step] = weizhi[step]
                                            screen.blit(hei, weizhi[step])

                                        else:
                                            pass
                                    if turn[t] % 2 == 0:
                                        screen.blit(bai, mouse)

                                        if event.type == pygame.MOUSEBUTTONDOWN:
                                            step = getstep()
                                            if step in kong:
                                                del kong[kong.index(step)]
                                                keep_going = False
                                                blitbai.append(step)
                                                buzhoubai[step] = weizhi[step]
                                                screen.blit(bai, weizhi[step])


                                            else:
                                                pass
                                if ti ==1:
                                    if turn[t] % 2 == 1:
                                        s = screen.blit(hei, mouse)
                                        if event.type == pygame.MOUSEBUTTONDOWN:
                                            step = getstep()
                                            if step in kong:
                                                a = kong.index(step)
                                                del kong[kong.index(step)]
                                                keep_going = False

                                                blithei.append(step)
                                                buzhouhei[step] = weizhi[step]
                                                screen.blit(hei, weizhi[step])

                                            else:
                                                pass
                                    if turn[t] % 2 == 0:

                                        step = easycomputer()
                                        if step in kong:
                                            del kong[kong.index(step)]
                                            keep_going = False
                                            blitbai.append(step)
                                            buzhoubai[step] = weizhi[step]
                                            screen.blit(bai, weizhi[step])


                                        else:
                                            pass

                        if event.type == pygame.MOUSEBUTTONDOWN or answer == 0 or answer == 1:

                            if playagain() == True or answer == 0 or answer == 1:
                                keep_going = False
                                blithei = []
                                answer = 2
                                iii = False
                                blitbai = []
                                buzhouhei = {}
                                buzhoubai = {}
                                nowinner = True
                                going = False
                                ko = False
                                kong = [1, 2, 3, 4, 5, 6, 7, 8, 9]

                        blii()
                        win()
                        screen.blit(again, (100, 70))
                        pygame.display.update()
                        clock.tick(100)














